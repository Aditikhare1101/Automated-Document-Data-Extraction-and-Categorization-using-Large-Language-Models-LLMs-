import os
import sys
import django
import streamlit as st
from PIL import Image
import torch
from transformers import DonutProcessor, VisionEncoderDecoderModel
import re
from document_parser.models import ParsedDocument
from django.core.files.base import ContentFile

# Set up Django environment
sys.path.append(os.path.join(os.path.dirname(__file__), 'document_parser'))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")

try:
    django.setup()
    print("Django setup completed successfully.")
except Exception as e:
    print("Error during Django setup:", e)

# Load the model and processor
processor = DonutProcessor.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")
model = VisionEncoderDecoderModel.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")

# Streamlit interface
st.title("Document Parsing with DONUT")

# Image upload
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Processing the image
    pixel_values = processor(image, return_tensors="pt").pixel_values

    # Inference
    task_prompt = "<s_cord-v2>"
    decoder_input_ids = processor.tokenizer(task_prompt, add_special_tokens=False, return_tensors="pt")["input_ids"]

    device = "cuda" if torch.cuda.is_available() else "cpu"
    model.to(device)

    outputs = model.generate(pixel_values.to(device),
                             decoder_input_ids=decoder_input_ids.to(device),
                             max_length=model.decoder.config.max_position_embeddings,
                             early_stopping=True,
                             pad_token_id=processor.tokenizer.pad_token_id,
                             eos_token_id=processor.tokenizer.eos_token_id,
                             use_cache=True,
                             num_beams=1,
                             bad_words_ids=[[processor.tokenizer.unk_token_id]],
                             return_dict_in_generate=True,
                             output_scores=True)

    # Decode output
    sequence = processor.batch_decode(outputs.sequences)[0]
    sequence = sequence.replace(processor.tokenizer.eos_token, "").replace(processor.tokenizer.pad_token, "")
    sequence = re.sub(r"<.*?>", "", sequence, count=1).strip()

    # Convert to JSON
    processor_json = processor.token2json(sequence)

    # Display the result
    st.subheader("Extracted Data")
    st.json(processor_json)

    # Save the data into the Django database
    try:
        parsed_document = ParsedDocument(extracted_data=processor_json)
        image_data = uploaded_file.read()
        parsed_document.image.save(uploaded_file.name, ContentFile(image_data))
        parsed_document.save()
        st.success("Data saved to Django database!")
    except Exception as e:
        st.error(f"Error saving data to Django database: {e}")
