# # test_pytorch_transformers.py
# import torch
# from transformers import DonutProcessor, VisionEncoderDecoderModel

# print(f"PyTorch version: {torch.__version__}")
# print("Transformers and PyTorch are successfully imported.")


import sys

print("Python Path:")
for path in sys.path:
    print(path)
