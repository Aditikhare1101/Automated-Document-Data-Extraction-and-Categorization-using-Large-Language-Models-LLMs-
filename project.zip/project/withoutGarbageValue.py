import streamlit as st
import pytesseract #For Optical Character Recognition (OCR) to extract text from images.
import sqlite3
import re #For regular expressions to find specific text patterns.
import json
from PIL import Image
import pandas as pd  # Import pandas for data manipulation

# Function to extract data from the cleaned text
def extract_data(cleaned_text):
    data = {
        "transaction_reference": "N/A",
        "payment_reference": "N/A",
        "recipient_name": "N/A",
        "transaction_amount": "N/A",
        "timestamp": "N/A",
        "discount": "N/A",
        "total": "N/A",
        "subtotal": "N/A",
        "sales_tax": "N/A",
        "items": []
    }

    # Extracting the total amount using regex
    total_match = re.search(r'Total\s*([\d,\.]+)', cleaned_text)
    if total_match:
        data["total"] = total_match.group(1).replace(',', '')

    # Extracting subtotal
    subtotal_match = re.search(r'Subtotal\s*([\d,\.]+)', cleaned_text)
    if subtotal_match:
        data["subtotal"] = subtotal_match.group(1).replace(',', '')

    # Extracting sales tax
    sales_tax_match = re.search(r'Sales Tax\s*([\d,\.]+)', cleaned_text)
    if sales_tax_match:
        data["sales_tax"] = sales_tax_match.group(1).replace(',', '')

    # Extracting items (this can vary based on your invoice format)
    items_section = re.findall(r'(\d+)\s+(.*?)\s+(-?\d+\.\d{2})', cleaned_text)
    for quantity, description, price in items_section:
        item = {
            "quantity": quantity,
            "description": description.strip(),
            "amount": price.strip()
        }
        data["items"].append(item)

    return data

# Function to save extracted data to the database
def save_to_db(conn, extracted_data, filename):
    c = conn.cursor()
    
    # Create the table if it doesn't exist
    c.execute('''CREATE TABLE IF NOT EXISTS document_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT,
                    transaction_reference TEXT,
                    payment_reference TEXT,
                    recipient_name TEXT,
                    transaction_amount TEXT,
                    timestamp TEXT,
                    discount TEXT,
                    total TEXT,
                    subtotal TEXT,
                    sales_tax TEXT,
                    items TEXT
                )''')

    #used to convert a Python list of dictionaries (or other Python objects) into a JSON string.
    items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
    
    c.execute('''INSERT INTO document_data 
                 (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
                  timestamp, discount, total, subtotal, sales_tax, items) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
              (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
               extracted_data["recipient_name"], extracted_data["transaction_amount"],
               extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
               extracted_data.get("subtotal", "N/A"), extracted_data.get("sales_tax", "N/A"),
               items_json))

    conn.commit()

# Function to display the database content as a table
def display_database_data(conn):
    c = conn.cursor()
    
    # Query the database for all data
    c.execute("SELECT * FROM document_data")
    data = c.fetchall()

    # Convert the data to a pandas DataFrame for better presentation
    df = pd.DataFrame(data, columns=["ID", "Filename", "Transaction Reference", "Payment Reference", 
                                     "Recipient Name", "Transaction Amount", "Timestamp", "Discount", 
                                     "Total", "Subtotal", "Sales Tax", "Items"])

    return df

# Streamlit application
st.title("Invoice Data Extraction")

uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
if uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
    # Perform OCR on the uploaded image
    extracted_text = pytesseract.image_to_string(image)

    # Display the extracted text
    st.subheader("Extracted Text:")
    st.write(extracted_text)

    # Clean and process the text
    cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
    st.subheader("Cleaned Sequence:")
    st.write(cleaned_text)

    # Extract relevant data
    extracted_data = extract_data(cleaned_text)

    # Display extracted data
    st.subheader("Extracted Data:")
    st.json(extracted_data)

    # Save data to SQLite database
    conn = sqlite3.connect('document_parsing.db')
    save_to_db(conn, extracted_data, uploaded_file.name)
    conn.close()

    st.success("Data has been extracted and saved to the database.")

# Connect to the database and display the data in a table format
conn = sqlite3.connect('document_parsing.db')
df = display_database_data(conn)
st.subheader("Database Content:")
st.dataframe(df)  # Display the DataFrame as a table in Streamlit
conn.close()





# import streamlit as st
# import pytesseract
# import sqlite3
# import re
# import json
# from PIL import Image

# # Function to extract data from the cleaned text
# def extract_data(cleaned_text):
#     data = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "subtotal": "N/A",
#         "sales_tax": "N/A",
#         "items": []
#     }

#     # Extracting the total amount using regex
#     total_match = re.search(r'Total\s*([\d,\.]+)', cleaned_text)
#     if total_match:
#         data["total"] = total_match.group(1).replace(',', '')

#     # Extracting subtotal
#     subtotal_match = re.search(r'Subtotal\s*([\d,\.]+)', cleaned_text)
#     if subtotal_match:
#         data["subtotal"] = subtotal_match.group(1).replace(',', '')

#     # Extracting sales tax
#     sales_tax_match = re.search(r'Sales Tax\s*([\d,\.]+)', cleaned_text)
#     if sales_tax_match:
#         data["sales_tax"] = sales_tax_match.group(1).replace(',', '')

#     # Extracting items (this can vary based on your invoice format)
#     items_section = re.findall(r'(\d+)\s+(.*?)\s+(-?\d+\.\d{2})', cleaned_text)
#     for quantity, description, price in items_section:
#         item = {
#             "quantity": quantity,
#             "description": description.strip(),
#             "amount": price.strip()
#         }
#         data["items"].append(item)

#     return data

# # Function to save extracted data to the database
# def save_to_db(conn, extracted_data, filename):
#     c = conn.cursor()
    
#     # Create the table if it doesn't exist
#     c.execute('''CREATE TABLE IF NOT EXISTS document_data (
#                     id INTEGER PRIMARY KEY AUTOINCREMENT,
#                     filename TEXT,
#                     transaction_reference TEXT,
#                     payment_reference TEXT,
#                     recipient_name TEXT,
#                     transaction_amount TEXT,
#                     timestamp TEXT,
#                     discount TEXT,
#                     total TEXT,
#                     subtotal TEXT,
#                     sales_tax TEXT,
#                     items TEXT
#                 )''')

#     items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
#     c.execute('''INSERT INTO document_data 
#                  (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
#                   timestamp, discount, total, subtotal, sales_tax, items) 
#                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
#               (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
#                extracted_data["recipient_name"], extracted_data["transaction_amount"],
#                extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
#                extracted_data.get("subtotal", "N/A"), extracted_data.get("sales_tax", "N/A"),
#                items_json))

#     conn.commit()

# # Streamlit application
# st.title("Invoice Data Extraction")

# uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
# if uploaded_file is not None:
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
#     # Perform OCR on the uploaded image
#     extracted_text = pytesseract.image_to_string(image)

#     # Display the extracted text
#     st.subheader("Extracted Text:")
#     st.write(extracted_text)

#     # Clean and process the text
#     cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
#     st.subheader("Cleaned Sequence:")
#     st.write(cleaned_text)

#     # Extract relevant data
#     extracted_data = extract_data(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Save data to SQLite database
#     conn = sqlite3.connect('document_parsing.db')
#     save_to_db(conn, extracted_data, uploaded_file.name)
#     conn.close()

#     st.success("Data has been extracted and saved to the database.")





# import streamlit as st
# import pytesseract
# import sqlite3
# import re
# import json  # Ensure this is imported
# from PIL import Image

# # Function to extract data from the cleaned text
# def extract_data(cleaned_text):
#     data = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Extracting the total amount using regex
#     total_match = re.search(r'Total\s*([\d,\.]+)', cleaned_text)
#     if total_match:
#         data["total"] = total_match.group(1).replace(',', '')

#     # Extracting subtotal
#     subtotal_match = re.search(r'Subtotal\s*([\d,\.]+)', cleaned_text)
#     if subtotal_match:
#         data["subtotal"] = subtotal_match.group(1).replace(',', '')

#     # Extracting sales tax
#     sales_tax_match = re.search(r'Sales Tax\s*([\d,\.]+)', cleaned_text)
#     if sales_tax_match:
#         data["sales_tax"] = sales_tax_match.group(1).replace(',', '')

#     # Extracting items (this can vary based on your invoice format)
#     items_section = re.findall(r'(\d+)\s+(.*?)\s+(-?\d+\.\d{2})', cleaned_text)
#     for quantity, description, price in items_section:
#         item = {
#             "quantity": quantity,
#             "description": description.strip(),
#             "amount": price.strip()
#         }
#         data["items"].append(item)

#     # For future invoices, you might want to extract other fields like:
#     # transaction_reference, payment_reference, recipient_name, etc.

#     return data

# # Function to save extracted data to the database
# def save_to_db(conn, extracted_data, filename):
#     c = conn.cursor()
#     c.execute("DROP TABLE IF EXISTS document_data")  # Drop table if it exists
#     c.execute('''CREATE TABLE IF NOT EXISTS document_data (
#                     id INTEGER PRIMARY KEY,
#                     filename TEXT,
#                     transaction_reference TEXT,
#                     payment_reference TEXT,
#                     recipient_name TEXT,
#                     transaction_amount TEXT,
#                     timestamp TEXT,
#                     discount TEXT,
#                     total TEXT,
#                     subtotal TEXT,
#                     sales_tax TEXT,
#                     items TEXT
#                 )''')

#     items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
#     c.execute('''INSERT INTO document_data 
#                  (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
#                   timestamp, discount, total, subtotal, sales_tax, items) 
#                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
#               (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
#                extracted_data["recipient_name"], extracted_data["transaction_amount"],
#                extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
#                extracted_data.get("subtotal", "N/A"), extracted_data.get("sales_tax", "N/A"),
#                items_json))

#     conn.commit()

# # Streamlit application
# st.title("Invoice Data Extraction")

# uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
# if uploaded_file is not None:
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
#     # Perform OCR on the uploaded image
#     extracted_text = pytesseract.image_to_string(image)

#     # Display the extracted text
#     st.subheader("Extracted Text:")
#     st.write(extracted_text)

#     # Clean and process the text
#     cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
#     st.subheader("Cleaned Sequence:")
#     st.write(cleaned_text)

#     # Extract relevant data
#     extracted_data = extract_data(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Save data to SQLite database
#     conn = sqlite3.connect('document_parsing.db')
#     save_to_db(conn, extracted_data, uploaded_file.name)
#     conn.close()

#     st.success("Data has been extracted and saved to the database.")





#PAYMENT

# import streamlit as st
# import pytesseract
# import sqlite3
# import re
# import json  # Ensure this is imported
# from PIL import Image

# # Function to extract data from the cleaned text
# def extract_data(cleaned_text):
#     data = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Improved regex to find relevant information
#     transaction_ref_match = re.search(r'Transaction Reference No\s*‘?(\S+)', cleaned_text)
#     if transaction_ref_match:
#         data["transaction_reference"] = transaction_ref_match.group(1)

#     payment_ref_match = re.search(r'Payment Gateway Reference\s*‘?(\S+)', cleaned_text)
#     if payment_ref_match:
#         data["payment_reference"] = payment_ref_match.group(1)

#     recipient_name_match = re.search(r'Student Name\s*‘?(.+?)\s*Student Details', cleaned_text)
#     if recipient_name_match:
#         data["recipient_name"] = recipient_name_match.group(1).strip()

#     transaction_amount_match = re.search(r'Transaction Amount\s*Rs\.\s*([\d,\.]+)', cleaned_text)
#     if transaction_amount_match:
#         data["transaction_amount"] = transaction_amount_match.group(1).replace(',', '')

#     timestamp_match = re.search(r'Timestamp\s*([A-Za-z\s,]+[\d:]+)', cleaned_text)
#     if timestamp_match:
#         data["timestamp"] = timestamp_match.group(1).strip()

#     # Assuming there are no itemized products in this example, we will not extract items
#     # If there were items, you would include similar regex for item extraction

#     return data

# # Function to save extracted data to the database
# def save_to_db(conn, extracted_data, filename):
#     c = conn.cursor()
#     c.execute("DROP TABLE IF EXISTS document_data")  # Drop table if it exists
#     c.execute('''CREATE TABLE IF NOT EXISTS document_data (
#                     id INTEGER PRIMARY KEY,
#                     filename TEXT,
#                     transaction_reference TEXT,
#                     payment_reference TEXT,
#                     recipient_name TEXT,
#                     transaction_amount TEXT,
#                     timestamp TEXT,
#                     discount TEXT,
#                     total TEXT,
#                     items TEXT
#                 )''')

#     items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
#     c.execute('''INSERT INTO document_data 
#                  (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
#                   timestamp, discount, total, items) 
#                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
#               (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
#                extracted_data["recipient_name"], extracted_data["transaction_amount"],
#                extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
#                items_json))

#     conn.commit()

# # Streamlit application
# st.title("Invoice Data Extraction")

# uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
# if uploaded_file is not None:
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
#     # Perform OCR on the uploaded image
#     extracted_text = pytesseract.image_to_string(image)

#     # Display the extracted text
#     st.subheader("Extracted Text:")
#     st.write(extracted_text)

#     # Clean and process the text
#     cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
#     st.subheader("Cleaned Sequence:")
#     st.write(cleaned_text)

#     # Extract relevant data
#     extracted_data = extract_data(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Save data to SQLite database
#     conn = sqlite3.connect('document_parsing.db')
#     save_to_db(conn, extracted_data, uploaded_file.name)
#     conn.close()

#     st.success("Data has been extracted and saved to the database.")


#INVOICE

# import streamlit as st
# import pytesseract
# import sqlite3
# import re
# import json  # Ensure this is imported
# from PIL import Image

# # Function to extract data from the cleaned text
# def extract_data(cleaned_text):
#     data = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Improved regex to find relevant information
#     total_match = re.search(r'TOTAL\s*\$?([\d,.]+)', cleaned_text)
#     if total_match:
#         data["total"] = total_match.group(1).replace(',', '')

#     transaction_amount_match = re.search(r'\$?([\d,.]+)', cleaned_text)
#     if transaction_amount_match:
#         data["transaction_amount"] = transaction_amount_match.group(1).replace(',', '')

#     item_match = re.findall(r'(\w+)\s+\$?([\d,.]+)', cleaned_text)  # Find items with prices
#     for item in item_match:
#         data["items"].append({
#             "category": item[0].strip(),
#             "amount": item[1].replace(',', '')
#         })

#     return data

# # Function to save extracted data to the database
# def save_to_db(conn, extracted_data, filename):
#     c = conn.cursor()
#     c.execute("DROP TABLE IF EXISTS document_data")  # Drop table if it exists
#     c.execute('''CREATE TABLE IF NOT EXISTS document_data (
#                     id INTEGER PRIMARY KEY,
#                     filename TEXT,
#                     transaction_reference TEXT,
#                     payment_reference TEXT,
#                     recipient_name TEXT,
#                     transaction_amount TEXT,
#                     timestamp TEXT,
#                     discount TEXT,
#                     total TEXT,
#                     items TEXT
#                 )''')

#     items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
#     c.execute('''INSERT INTO document_data 
#                  (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
#                   timestamp, discount, total, items) 
#                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
#               (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
#                extracted_data["recipient_name"], extracted_data["transaction_amount"],
#                extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
#                items_json))

#     conn.commit()

# # Streamlit application
# st.title("Invoice Data Extraction")

# uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
# if uploaded_file is not None:
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
#     # Perform OCR on the uploaded image
#     extracted_text = pytesseract.image_to_string(image)

#     # Display the extracted text
#     st.subheader("Extracted Text:")
#     st.write(extracted_text)

#     # Clean and process the text
#     cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
#     st.subheader("Cleaned Sequence:")
#     st.write(cleaned_text)

#     # Extract relevant data
#     extracted_data = extract_data(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Save data to SQLite database
#     conn = sqlite3.connect('document_parsing.db')
#     save_to_db(conn, extracted_data, uploaded_file.name)
#     conn.close()

#     st.success("Data has been extracted and saved to the database.")





# import streamlit as st
# import pytesseract
# import sqlite3
# import re
# import pandas as pd
# from PIL import Image

# # Function to extract data from the cleaned text
# def extract_data(cleaned_text):
#     data = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Use regex to find relevant information
#     transaction_reference_match = re.search(r'Transaction Reference No\s*([\w-]+)', cleaned_text)
#     if transaction_reference_match:
#         data["transaction_reference"] = transaction_reference_match.group(1)

#     payment_reference_match = re.search(r'Payment Gateway Reference\s*([\w-]+)', cleaned_text)
#     if payment_reference_match:
#         data["payment_reference"] = payment_reference_match.group(1)

#     recipient_name_match = re.search(r'Student Name\s*([A-Za-z\s]+)', cleaned_text)
#     if recipient_name_match:
#         data["recipient_name"] = recipient_name_match.group(1).strip()

#     transaction_amount_match = re.search(r'Transaction Amount\s*Rs\.?\s*([\d,]+\.\d{2})', cleaned_text)
#     if transaction_amount_match:
#         data["transaction_amount"] = transaction_amount_match.group(1)

#     timestamp_match = re.search(r'Timestamp\s*([\w\s,]+)', cleaned_text)
#     if timestamp_match:
#         data["timestamp"] = timestamp_match.group(1).strip()

#     # Extract items (if applicable)
#     item_match = re.search(r'Fee Category\s*(.*?)(?:Transaction Amount|Timestamp)\s*Rs\.? (\d+(\.\d{1,2})?)', cleaned_text)
#     if item_match:
#         item = {
#             "category": "Fee Category Student Academic Fee",
#             "amount": item_match.group(2)
#         }
#         data["items"].append(item)

#     return data

# # Function to save extracted data to the database
# def save_to_db(conn, extracted_data, filename):
#     c = conn.cursor()
#     c.execute('''CREATE TABLE IF NOT EXISTS document_data (
#                     id INTEGER PRIMARY KEY,
#                     filename TEXT,
#                     transaction_reference TEXT,
#                     payment_reference TEXT,
#                     recipient_name TEXT,
#                     transaction_amount TEXT,
#                     timestamp TEXT,
#                     discount TEXT,
#                     total TEXT,
#                     items TEXT
#                 )''')

#     items_json = json.dumps(extracted_data["items"])  # Convert items to JSON string
#     c.execute('''INSERT INTO document_data 
#                  (filename, transaction_reference, payment_reference, recipient_name, transaction_amount,
#                   timestamp, discount, total, items) 
#                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
#               (filename, extracted_data["transaction_reference"], extracted_data["payment_reference"],
#                extracted_data["recipient_name"], extracted_data["transaction_amount"],
#                extracted_data["timestamp"], extracted_data["discount"], extracted_data["total"],
#                items_json))

#     conn.commit()

# # Streamlit application
# st.title("Invoice Data Extraction")

# uploaded_file = st.file_uploader("Upload Invoice", type=["jpg", "jpeg", "png"])
# if uploaded_file is not None:
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Invoice', use_column_width=True)
    
#     # Perform OCR on the uploaded image
#     extracted_text = pytesseract.image_to_string(image)

#     # Display the extracted text
#     st.subheader("Extracted Text:")
#     st.write(extracted_text)

#     # Clean and process the text
#     cleaned_text = re.sub(r'\s+', ' ', extracted_text).strip()  # Basic cleanup
#     st.subheader("Cleaned Sequence:")
#     st.write(cleaned_text)

#     # Extract relevant data
#     extracted_data = extract_data(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Save data to SQLite database
#     conn = sqlite3.connect('document_parsing.db')
#     save_to_db(conn, extracted_data, uploaded_file.name)
#     conn.close()

#     st.success("Data has been extracted and saved to the database.")








# import streamlit as st
# import sqlite3
# import pytesseract
# from PIL import Image
# import re

# # Set up SQLite database connection
# def create_connection():
#     conn = sqlite3.connect('document_parsing.db')
#     return conn

# def create_table(conn):
#     cursor = conn.cursor()
#     cursor.execute('''
#         CREATE TABLE IF NOT EXISTS invoices (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             transaction_reference TEXT,
#             payment_reference TEXT,
#             recipient_name TEXT,
#             transaction_amount REAL,
#             timestamp TEXT,
#             discount REAL,
#             total REAL,
#             items TEXT
#         )
#     ''')
#     conn.commit()

# # Function to extract fields
# def extract_fields(sequence):
#     fields = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Updated regex patterns for specific fields
#     transaction_ref_pattern = r"(?i)Transaction Reference No[‘']?[\s]*(\w+)"
#     payment_ref_pattern = r"(?i)Payment Gateway Reference[‘']?[\s]*(\d+)"
#     recipient_name_pattern = r"(?i)Student Name[‘']?[\s]*([^‘']+)"
#     amount_pattern = r"(?i)Transaction Amount\s*Rs\.\s*([\d,]+\.\d{2})"
#     timestamp_pattern = r"(?i)Timestamp\s*([A-Za-z\s\d,:]+)"
#     discount_pattern = r"(?i)Discount\s*Rs\.\s*([\d,]+\.\d{2})"  # Assuming discount line is present in future texts
#     total_pattern = r"(?i)Total\s*Rs\.\s*([\d,]+\.\d{2})"  # Assuming total line is present in future texts

#     # Extract fields using regex patterns
#     for key, pattern in [
#         ("transaction_reference", transaction_ref_pattern),
#         ("payment_reference", payment_ref_pattern),
#         ("recipient_name", recipient_name_pattern),
#         ("transaction_amount", amount_pattern),
#         ("timestamp", timestamp_pattern),
#         ("discount", discount_pattern),
#         ("total", total_pattern)
#     ]:
#         match = re.search(pattern, sequence)
#         if match:
#             fields[key] = match.group(1).strip()

#     # Extracting items from the sequence (if applicable)
#     item_pattern = r"(?i)(Fee Category[^\n]+)\s*Transaction Amount\s*Rs\.\s*([\d,]+\.\d{2})"  # Adjust the pattern as needed
#     items = re.findall(item_pattern, sequence)
#     for item in items:
#         fields["items"].append({"category": item[0].strip(), "amount": item[1].strip()})

#     return fields

# # Streamlit application
# st.title("Invoice Data Extraction")

# # File uploader for invoice documents
# uploaded_file = st.file_uploader("Upload an Invoice Document", type=["png", "jpg", "jpeg"])

# if uploaded_file is not None:
#     # Process the uploaded image
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Image', use_column_width=True)

#     # Perform OCR to extract text from the image
#     extracted_text = pytesseract.image_to_string(image)

#     # Clean the extracted text (you may need to refine this step)
#     cleaned_text = extracted_text.replace('\n', ' ')

#     # Extract fields from cleaned text
#     extracted_data = extract_fields(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Store the extracted data in SQLite database
#     if st.button("Save to Database"):
#         with create_connection() as conn:
#             create_table(conn)
#             cursor = conn.cursor()
#             cursor.execute('''
#                 INSERT INTO invoices (transaction_reference, payment_reference, recipient_name,
#                                       transaction_amount, timestamp, discount, total, items)
#                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)
#             ''', (
#                 extracted_data["transaction_reference"],
#                 extracted_data["payment_reference"],
#                 extracted_data["recipient_name"],
#                 extracted_data["transaction_amount"],
#                 extracted_data["timestamp"],
#                 extracted_data["discount"],
#                 extracted_data["total"],
#                 str(extracted_data["items"])
#             ))
#             conn.commit()
#             st.success("Data saved successfully!")





# import streamlit as st
# import sqlite3
# import pytesseract
# from PIL import Image
# import re

# # Set up SQLite database connection
# def create_connection():
#     conn = sqlite3.connect('document_parsing.db')
#     return conn

# def create_table(conn):
#     cursor = conn.cursor()
#     cursor.execute('''
#         CREATE TABLE IF NOT EXISTS invoices (
#             id INTEGER PRIMARY KEY AUTOINCREMENT,
#             transaction_reference TEXT,
#             payment_reference TEXT,
#             recipient_name TEXT,
#             transaction_amount REAL,
#             timestamp TEXT,
#             discount REAL,
#             total REAL,
#             items TEXT
#         )
#     ''')
#     conn.commit()

# # Function to extract fields
# def extract_fields(sequence):
#     fields = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "discount": "N/A",
#         "total": "N/A",
#         "items": []
#     }

#     # Updated regex patterns for specific fields
#     transaction_ref_pattern = r"(?i)Transaction Reference No[‘']?([^‘']+)"
#     payment_ref_pattern = r"(?i)Payment Gateway Reference[‘']?(\d+)"
#     recipient_name_pattern = r"(?i)Student Name[‘']?([^‘']+)"
#     amount_pattern = r"(?i)Transaction Amount\s*Rs\.\s*([\d,]+\.\d{2})"
#     timestamp_pattern = r"(?i)Timestamp\s*([A-Za-z\s\d,:]+)"
#     discount_pattern = r"(?i)Discount\s*Rs\.\s*([\d,]+\.\d{2})"  # Assuming discount line is present in future texts
#     total_pattern = r"(?i)Total\s*Rs\.\s*([\d,]+\.\d{2})"  # Assuming total line is present in future texts

#     # Extract fields using regex patterns
#     for key, pattern in [
#         ("transaction_reference", transaction_ref_pattern),
#         ("payment_reference", payment_ref_pattern),
#         ("recipient_name", recipient_name_pattern),
#         ("transaction_amount", amount_pattern),
#         ("timestamp", timestamp_pattern),
#         ("discount", discount_pattern),
#         ("total", total_pattern)
#     ]:
#         match = re.search(pattern, sequence)
#         if match:
#             fields[key] = match.group(1).strip()

#     # Extracting items from the sequence (if applicable)
#     item_pattern = r"(?i)Fee Category\s*([^:]+):\s*([^:]+)"  # This pattern may need refinement based on your actual text structure
#     items = re.findall(item_pattern, sequence)
#     for item in items:
#         fields["items"].append({"category": item[0].strip(), "description": item[1].strip()})

#     return fields

# # Streamlit application
# st.title("Invoice Data Extraction")

# # File uploader for invoice documents
# uploaded_file = st.file_uploader("Upload an Invoice Document", type=["png", "jpg", "jpeg"])

# if uploaded_file is not None:
#     # Process the uploaded image
#     image = Image.open(uploaded_file)
#     st.image(image, caption='Uploaded Image', use_column_width=True)

#     # Perform OCR to extract text from the image
#     extracted_text = pytesseract.image_to_string(image)

#     # Clean the extracted text (you may need to refine this step)
#     cleaned_text = extracted_text.replace('\n', ' ')

#     # Extract fields from cleaned text
#     extracted_data = extract_fields(cleaned_text)

#     # Display extracted data
#     st.subheader("Extracted Data:")
#     st.json(extracted_data)

#     # Store the extracted data in SQLite database
#     if st.button("Save to Database"):
#         with create_connection() as conn:
#             create_table(conn)
#             cursor = conn.cursor()
#             cursor.execute('''
#                 INSERT INTO invoices (transaction_reference, payment_reference, recipient_name,
#                                       transaction_amount, timestamp, discount, total, items)
#                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)
#             ''', (
#                 extracted_data["transaction_reference"],
#                 extracted_data["payment_reference"],
#                 extracted_data["recipient_name"],
#                 extracted_data["transaction_amount"],
#                 extracted_data["timestamp"],
#                 extracted_data["discount"],
#                 extracted_data["total"],
#                 str(extracted_data["items"])
#             ))
#             conn.commit()
#             st.success("Data saved successfully!")







# import streamlit as st
# import sqlite3
# import re
# from PIL import Image
# import pytesseract

# # Database connection
# def create_connection():
#     conn = sqlite3.connect('document_parsing.db')
#     return conn

# def create_table(conn):
#     cursor = conn.cursor()
#     cursor.execute('''
#     CREATE TABLE IF NOT EXISTS invoices (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         transaction_reference TEXT,
#         recipient_name TEXT,
#         transaction_amount TEXT,
#         timestamp TEXT,
#         total TEXT,
#         discount TEXT,
#         items TEXT
#     )
#     ''')
#     conn.commit()

# def insert_invoice(conn, fields):
#     cursor = conn.cursor()
#     cursor.execute('''
#     INSERT INTO invoices (transaction_reference, recipient_name, transaction_amount, timestamp, total, discount, items)
#     VALUES (?, ?, ?, ?, ?, ?, ?)
#     ''', (fields["transaction_reference"],
#           fields["recipient_name"],
#           fields["transaction_amount"],
#           fields["timestamp"],
#           fields["total"],
#           fields["discount"],
#           str(fields["items"])))  # Store items as a string representation
#     conn.commit()

# # Function to extract fields from the cleaned sequence
# def extract_fields(sequence):
#     fields = {
#         "transaction_reference": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A",
#         "items": [],
#         "total": "N/A",
#         "discount": "N/A"
#     }

#     # Adjusted regex patterns to extract different fields
#     transaction_ref_pattern = r"(?i)(invoice\snumber|reference)[\s:]*([A-Za-z0-9-]+)"
#     recipient_name_pattern = r"(?i)(name)[\s:]*([A-Za-z\s]+)"
#     amount_pattern = r"(?i)(total|amount)[\s:]*([\d,.]+)"
#     timestamp_pattern = r"(?i)(\d{1,2}:\d{2}.*?[APMapm]{2})"  # Adjusting for time format
#     discount_pattern = r"(?i)(discount)[\s:]*([\d,]+\.\d{2}|\d+)"

#     # Extract Transaction Reference
#     match = re.search(transaction_ref_pattern, sequence)
#     if match:
#         fields["transaction_reference"] = match.group(2)

#     # Extract Recipient Name
#     match = re.search(recipient_name_pattern, sequence)
#     if match:
#         fields["recipient_name"] = match.group(2).strip()

#     # Extract Transaction Amount
#     match = re.search(amount_pattern, sequence)
#     if match:
#         fields["transaction_amount"] = match.group(2)

#     # Extract Timestamp
#     match = re.search(timestamp_pattern, sequence)
#     if match:
#         fields["timestamp"] = match.group(0)  # Captures the entire matched time string

#     # Extract Discount
#     match = re.search(discount_pattern, sequence)
#     if match:
#         fields["discount"] = match.group(2)

#     # Extract items (If applicable)
#     item_pattern = r"(?i)<s_nm>\s*([^<]+)\s*</s_nm>\s*<s_unitprice>\s*([\d,.]+)\s*</s_unitprice>\s*<s_cnt>\s*(\d+)\s*</s_cnt>\s*<s_price>\s*([\d,.]*)\s*</s_price>"
#     for match in re.findall(item_pattern, sequence):
#         fields["items"].append({"name": match[0].strip(), "price": match[3].strip()})

#     # Extract total amount
#     match = re.search(r"(?i)<s_total_price>([\d,.]+)</s_total_price>", sequence)
#     if match:
#         fields["total"] = match.group(1)

#     return fields

# # Streamlit application
# def main():
#     st.title("Document Parsing Application")

#     # Upload Image
#     uploaded_file = st.file_uploader("Upload an Invoice Image", type=["png", "jpg", "jpeg"])
    
#     if uploaded_file is not None:
#         # Display uploaded image
#         image = Image.open(uploaded_file)
#         st.image(image, caption='Uploaded Image', use_column_width=True)

#         # Extract text from image
#         text = pytesseract.image_to_string(image)
#         st.write("Extracted Text:")
#         st.write(text)

#         # Cleaned sequence (This should be refined based on your use case)
#         cleaned_sequence = text  # Replace with your cleaning logic
#         st.write("Cleaned Sequence:")
#         st.write(cleaned_sequence)

#         # Extract fields from the cleaned sequence
#         extracted_fields = extract_fields(cleaned_sequence)
#         st.write("Extracted Data:")
#         st.json(extracted_fields)

#         # Database operations
#         conn = create_connection()
#         create_table(conn)
#         insert_invoice(conn, extracted_fields)
#         conn.close()

#         st.success("Invoice data saved to the database successfully.")

# if __name__ == "__main__":
#     main()






# import streamlit as st
# from PIL import Image
# import torch
# from transformers import DonutProcessor, VisionEncoderDecoderModel
# import re
# import sqlite3  # For database
# import json  # To handle JSON data

# # Load the model and processor
# processor = DonutProcessor.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")
# model = VisionEncoderDecoderModel.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")

# # Database setup
# conn = sqlite3.connect('document_parsing.db')
# c = conn.cursor()

# # Create a table if it doesn't exist
# c.execute('''
#     CREATE TABLE IF NOT EXISTS document_data (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         image_name TEXT,
#         transaction_reference TEXT,
#         payment_reference TEXT,
#         student_name TEXT,
#         transaction_amount TEXT,
#         timestamp TEXT,
#         data TEXT
#     )
# ''')
# conn.commit()

# # Function to clean the extracted text
# def clean_extracted_text(text):
#     # Remove non-printable characters
#     text = re.sub(r'[^\x20-\x7E]+', '', text)  # Removes non-ASCII characters
#     return text

# # Function to extract key fields from the sequence
# def extract_fields(sequence):
#     fields = {
#         "transaction_reference": "N/A",
#         "payment_reference": "N/A",
#         "student_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A"
#     }

#     # Updated regex patterns for specific fields
#     transaction_ref_pattern = r"(?i)(transaction\sreference\sno|reference\sno)[\s:]*([A-Za-z0-9]+)"
#     payment_ref_pattern = r"(?i)(payment\sgateway\sreference)[\s:]*([\d]+)"
#     student_name_pattern = r"(?i)(student\sname)[\s:]*([A-Za-z\s]+)"
#     amount_pattern = r"(?i)(transaction\samount|total)[\s:]*([\d,]+\.\d{2})"
#     timestamp_pattern = r"(?i)(timestamp|date)[\s:]*([\d\s:,AMP]+)"

#     # Extract Transaction Reference
#     match = re.search(transaction_ref_pattern, sequence)
#     if match:
#         fields["transaction_reference"] = match.group(2)

#     # Extract Payment Reference
#     match = re.search(payment_ref_pattern, sequence)
#     if match:
#         fields["payment_reference"] = match.group(2)

#     # Extract Student Name
#     match = re.search(student_name_pattern, sequence)
#     if match:
#         fields["student_name"] = match.group(2).strip()

#     # Extract Transaction Amount
#     match = re.search(amount_pattern, sequence)
#     if match:
#         fields["transaction_amount"] = match.group(2)

#     # Extract Timestamp
#     match = re.search(timestamp_pattern, sequence)
#     if match:
#         fields["timestamp"] = match.group(2)

#     return fields

# # Streamlit interface
# st.title("Document Parsing with DONUT")

# # Image upload
# uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

# if uploaded_file is not None:
#     # Open the image and convert it to RGB to ensure proper format
#     image = Image.open(uploaded_file).convert("RGB")
#     st.image(image, caption="Uploaded Image", use_column_width=True)

#     # Optional: check image size to ensure proper processing
#     st.write(f"Image size: {image.size}")

#     # Processing the image with DonutProcessor
#     try:
#         pixel_values = processor(image, return_tensors="pt").pixel_values

#         # Inference
#         task_prompt = "<s_cord-v2>"
#         decoder_input_ids = processor.tokenizer(task_prompt, add_special_tokens=False, return_tensors="pt")["input_ids"]

#         device = "cuda" if torch.cuda.is_available() else "cpu"
#         model.to(device)

#         outputs = model.generate(pixel_values.to(device),
#                                  decoder_input_ids=decoder_input_ids.to(device),
#                                  max_length=model.decoder.config.max_position_embeddings,
#                                  early_stopping=True,
#                                  pad_token_id=processor.tokenizer.pad_token_id,
#                                  eos_token_id=processor.tokenizer.eos_token_id,
#                                  use_cache=True,
#                                  num_beams=1,
#                                  bad_words_ids=[[processor.tokenizer.unk_token_id]],
#                                  return_dict_in_generate=True,
#                                  output_scores=True)

#         # Decode output
#         sequence = processor.batch_decode(outputs.sequences)[0]
#         sequence = sequence.replace(processor.tokenizer.eos_token, "").replace(processor.tokenizer.pad_token, "")
#         sequence = re.sub(r"<.*?>", "", sequence, count=1).strip()

#         # Clean the extracted text
#         cleaned_sequence = clean_extracted_text(sequence)

#         # Extract key fields from the sequence
#         extracted_fields = extract_fields(cleaned_sequence)

#         # Display the extracted fields
#         st.subheader("Extracted Data")
#         st.write(f"Transaction Reference: {extracted_fields['transaction_reference']}")
#         st.write(f"Payment Gateway Reference: {extracted_fields['payment_reference']}")
#         st.write(f"Student Name: {extracted_fields['student_name']}")
#         st.write(f"Transaction Amount: {extracted_fields['transaction_amount']}")
#         st.write(f"Timestamp: {extracted_fields['timestamp']}")

#         # Save the result in the database
#         json_data_str = json.dumps(cleaned_sequence)  # Convert JSON object to string
#         c.execute("INSERT INTO document_data (image_name, transaction_reference, payment_reference, student_name, transaction_amount, timestamp, data) VALUES (?, ?, ?, ?, ?, ?, ?)", 
#                   (uploaded_file.name, extracted_fields['transaction_reference'], extracted_fields['payment_reference'], extracted_fields['student_name'], extracted_fields['transaction_amount'], extracted_fields['timestamp'], json_data_str))
#         conn.commit()

#         st.success("Data saved to database successfully!")

#     except Exception as e:
#         st.error(f"Error processing the image: {e}")

# # Option to view saved data from the database
# if st.button("View saved data"):
#     try:
#         c.execute("SELECT * FROM document_data")
#         rows = c.fetchall()

#         st.subheader("Saved Data in Database")
#         for row in rows:
#             st.write(f"ID: {row[0]}, Image Name: {row[1]}")
#             st.write(f"Transaction Reference: {row[2]}")
#             st.write(f"Payment Gateway Reference: {row[3]}")
#             st.write(f"Student Name: {row[4]}")
#             st.write(f"Transaction Amount: {row[5]}")
#             st.write(f"Timestamp: {row[6]}")
#             st.json(json.loads(row[7]))  # Display raw JSON data

#     except Exception as e:
#         st.error(f"Error retrieving data: {e}")

# # Close the database connection after script execution
# conn.close()






# import streamlit as st
# from PIL import Image
# import torch
# from transformers import DonutProcessor, VisionEncoderDecoderModel
# import re
# import sqlite3  # For database
# import json  # To handle JSON data

# # Load the model and processor
# processor = DonutProcessor.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")
# model = VisionEncoderDecoderModel.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")

# # Database setup
# conn = sqlite3.connect('document_parsing.db')
# c = conn.cursor()

# # Create a table if it doesn't exist
# c.execute('''
#     CREATE TABLE IF NOT EXISTS document_data (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         image_name TEXT,
#         invoice_number TEXT,
#         recipient_name TEXT,
#         transaction_amount TEXT,
#         timestamp TEXT,
#         data TEXT
#     )
# ''')
# conn.commit()

# # Function to clean the extracted text
# def clean_extracted_text(text):
#     # Remove non-printable characters
#     text = re.sub(r'[^\x20-\x7E]+', '', text)  # Removes non-ASCII characters
#     # Clean up known patterns (e.g., extra characters)
#     text = re.sub(r'[^\w\s,.:]', '', text)  # Keep only alphanumeric, spaces, and common punctuation
#     return text

# # Function to extract key fields from the sequence
# def extract_fields(sequence):
#     fields = {
#         "invoice_number": "N/A",
#         "recipient_name": "N/A",
#         "transaction_amount": "N/A",
#         "timestamp": "N/A"
#     }

#     # Attempt to extract specific fields using regular expressions or keywords
#     invoice_pattern = r"(?i)(invoice|receipt|reference)[\s:]*([A-Za-z0-9]+)"
#     recipient_pattern = r"(?i)(recipient|name|payee)[\s:]*([A-Za-z\s]+)"
#     amount_pattern = r"(?i)(total|amount|payment)[\s:]*([\d,]+\.\d{2})"
#     timestamp_pattern = r"(?i)(date|time|timestamp)[\s:]*([\d:/\sAMP]+)"

#     # Extract Invoice Number
#     match = re.search(invoice_pattern, sequence)
#     if match:
#         fields["invoice_number"] = match.group(2)

#     # Extract Recipient Name
#     match = re.search(recipient_pattern, sequence)
#     if match:
#         fields["recipient_name"] = match.group(2).strip()

#     # Extract Transaction Amount
#     match = re.search(amount_pattern, sequence)
#     if match:
#         fields["transaction_amount"] = match.group(2)

#     # Extract Timestamp
#     match = re.search(timestamp_pattern, sequence)
#     if match:
#         fields["timestamp"] = match.group(2)

#     return fields

# # Streamlit interface
# st.title("Document Parsing with DONUT")

# # Image upload
# uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

# if uploaded_file is not None:
#     # Open the image and convert it to RGB to ensure proper format
#     image = Image.open(uploaded_file).convert("RGB")
#     st.image(image, caption="Uploaded Image", use_column_width=True)

#     # Optional: check image size to ensure proper processing
#     st.write(f"Image size: {image.size}")

#     # Processing the image with DonutProcessor
#     try:
#         pixel_values = processor(image, return_tensors="pt").pixel_values

#         # Inference
#         task_prompt = "<s_cord-v2>"
#         decoder_input_ids = processor.tokenizer(task_prompt, add_special_tokens=False, return_tensors="pt")["input_ids"]

#         device = "cuda" if torch.cuda.is_available() else "cpu"
#         model.to(device)

#         outputs = model.generate(pixel_values.to(device),
#                                  decoder_input_ids=decoder_input_ids.to(device),
#                                  max_length=model.decoder.config.max_position_embeddings,
#                                  early_stopping=True,
#                                  pad_token_id=processor.tokenizer.pad_token_id,
#                                  eos_token_id=processor.tokenizer.eos_token_id,
#                                  use_cache=True,
#                                  num_beams=1,
#                                  bad_words_ids=[[processor.tokenizer.unk_token_id]],
#                                  return_dict_in_generate=True,
#                                  output_scores=True)

#         # Decode output
#         sequence = processor.batch_decode(outputs.sequences)[0]
#         sequence = sequence.replace(processor.tokenizer.eos_token, "").replace(processor.tokenizer.pad_token, "")
#         sequence = re.sub(r"<.*?>", "", sequence, count=1).strip()

#         # Clean the extracted text using the function
#         cleaned_sequence = clean_extracted_text(sequence)

#         # Extract key fields from the sequence
#         extracted_fields = extract_fields(cleaned_sequence)

#         # Display the extracted fields
#         st.subheader("Extracted Data")
#         st.write(f"Invoice Number: {extracted_fields['invoice_number']}")
#         st.write(f"Recipient Name: {extracted_fields['recipient_name']}")
#         st.write(f"Transaction Amount: {extracted_fields['transaction_amount']}")
#         st.write(f"Timestamp: {extracted_fields['timestamp']}")

#         # Save the result in the database
#         json_data_str = json.dumps(cleaned_sequence)  # Convert JSON object to string
#         c.execute("INSERT INTO document_data (image_name, invoice_number, recipient_name, transaction_amount, timestamp, data) VALUES (?, ?, ?, ?, ?, ?)", 
#                   (uploaded_file.name, extracted_fields['invoice_number'], extracted_fields['recipient_name'], extracted_fields['transaction_amount'], extracted_fields['timestamp'], json_data_str))
#         conn.commit()

#         st.success("Data saved to database successfully!")

#     except Exception as e:
#         st.error(f"Error processing the image: {e}")

# # Option to view saved data from the database
# if st.button("View saved data"):
#     try:
#         c.execute("SELECT * FROM document_data")
#         rows = c.fetchall()

#         st.subheader("Saved Data in Database")
#         for row in rows:
#             st.write(f"ID: {row[0]}, Image Name: {row[1]}")
#             st.write(f"Invoice Number: {row[2]}")
#             st.write(f"Recipient Name: {row[3]}")
#             st.write(f"Transaction Amount: {row[4]}")
#             st.write(f"Timestamp: {row[5]}")
#             st.json(json.loads(row[6]))  # Display raw JSON data

#     except Exception as e:
#         st.error(f"Error retrieving data: {e}")

# # Close the database connection after script execution
# conn.close()







# import streamlit as st
# from PIL import Image
# import torch
# from transformers import DonutProcessor, VisionEncoderDecoderModel
# import re
# import sqlite3  # For database
# import json  # To handle JSON data

# # Load the model and processor
# processor = DonutProcessor.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")
# model = VisionEncoderDecoderModel.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")

# # Database setup
# conn = sqlite3.connect('document_parsing.db')
# c = conn.cursor()

# # Create a table if it doesn't exist
# c.execute('''
#     CREATE TABLE IF NOT EXISTS extracted_data (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         image_name TEXT,
#         data TEXT
#     )
# ''')
# conn.commit()

# # Function to clean the extracted text
# def clean_extracted_text(text):
#     # Remove non-printable characters
#     text = re.sub(r'[^\x20-\x7E]+', '', text)  # Removes non-ASCII characters
#     # Clean up known patterns (e.g., extra characters)
#     text = re.sub(r'[^\w\s,.:]', '', text)  # Keep only alphanumeric, spaces, and common punctuation
#     return text

# # Streamlit interface
# st.title("Document Parsing with DONUT")

# # Image upload
# uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

# if uploaded_file is not None:
#     # Open the image and convert it to RGB to ensure proper format
#     image = Image.open(uploaded_file).convert("RGB")
#     st.image(image, caption="Uploaded Image", use_column_width=True)

#     # Optional: check image size to ensure proper processing
#     st.write(f"Image size: {image.size}")

#     # Processing the image with DonutProcessor
#     try:
#         pixel_values = processor(image, return_tensors="pt").pixel_values

#         # Inference
#         task_prompt = "<s_cord-v2>"
#         decoder_input_ids = processor.tokenizer(task_prompt, add_special_tokens=False, return_tensors="pt")["input_ids"]

#         device = "cuda" if torch.cuda.is_available() else "cpu"
#         model.to(device)

#         outputs = model.generate(pixel_values.to(device),
#                                  decoder_input_ids=decoder_input_ids.to(device),
#                                  max_length=model.decoder.config.max_position_embeddings,
#                                  early_stopping=True,
#                                  pad_token_id=processor.tokenizer.pad_token_id,
#                                  eos_token_id=processor.tokenizer.eos_token_id,
#                                  use_cache=True,
#                                  num_beams=1,
#                                  bad_words_ids=[[processor.tokenizer.unk_token_id]],
#                                  return_dict_in_generate=True,
#                                  output_scores=True)

#         # Decode output
#         sequence = processor.batch_decode(outputs.sequences)[0]
#         sequence = sequence.replace(processor.tokenizer.eos_token, "").replace(processor.tokenizer.pad_token, "")
#         sequence = re.sub(r"<.*?>", "", sequence, count=1).strip()

#         # Clean the extracted text using the function
#         cleaned_sequence = clean_extracted_text(sequence)

#         # Convert to JSON
#         processor_json = processor.token2json(cleaned_sequence)

#         # Display the result
#         st.subheader("Extracted Data")
#         st.json(processor_json)

#         # Save the result in the database
#         json_data_str = json.dumps(processor_json)  # Convert JSON object to string
#         c.execute("INSERT INTO extracted_data (image_name, data) VALUES (?, ?)", 
#                   (uploaded_file.name, json_data_str))
#         conn.commit()

#         st.success("Data saved to database successfully!")

#     except Exception as e:
#         st.error(f"Error processing the image: {e}")

# # Option to view saved data from the database
# if st.button("View saved data"):
#     try:
#         c.execute("SELECT * FROM extracted_data")
#         rows = c.fetchall()

#         st.subheader("Saved Data in Database")
#         for row in rows:
#             st.write(f"ID: {row[0]}, Image Name: {row[1]}")
#             st.json(json.loads(row[2]))  # Convert string back to JSON and display

#     except Exception as e:
#         st.error(f"Error retrieving data: {e}")

# # Close the database connection after script execution
# conn.close()
