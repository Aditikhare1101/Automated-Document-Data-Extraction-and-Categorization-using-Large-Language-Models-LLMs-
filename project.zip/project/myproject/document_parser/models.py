# document_parser/models.py
from django.db import models

class ParsedDocument(models.Model):
    image = models.ImageField(upload_to='uploads/')  # Optional: Store the image
    extracted_data = models.JSONField()  # Store the extracted JSON data

    def __str__(self):
        return f"Document {self.id}"
