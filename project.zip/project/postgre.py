import streamlit as st
from PIL import Image
import torch
from transformers import DonutProcessor, VisionEncoderDecoderModel
import re
import psycopg2  # PostgreSQL database
import json  # To handle JSON data
import pandas as pd  # For displaying data as a table

# Load the model and processor
processor = DonutProcessor.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")
model = VisionEncoderDecoderModel.from_pretrained("fahmiaziz/finetune-donut-cord-v2.5")

# PostgreSQL Database connection
def create_connection():
    return psycopg2.connect(
        host="localhost",  # Change to your PostgreSQL host
        database="your_db_name",  # Change to your database name
        user="your_username",  # Change to your PostgreSQL username
        password="aditi"  # Change to your PostgreSQL password
    )

# Connect to PostgreSQL
conn = create_connection()
c = conn.cursor()

# Create a table if it doesn't exist
c.execute('''
    CREATE TABLE IF NOT EXISTS extracted_data (
        id SERIAL PRIMARY KEY,
        image_name VARCHAR(255),
        data JSON
    )
''')
conn.commit()

# Streamlit interface
st.title("Document Parsing with DONUT")

# Image upload
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    # Open the image and convert it to RGB to ensure proper format
    image = Image.open(uploaded_file).convert("RGB")
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Optional: check image size to ensure proper processing
    st.write(f"Image size: {image.size}")

    # Processing the image with DonutProcessor
    try:
        pixel_values = processor(image, return_tensors="pt").pixel_values

        # Inference
        task_prompt = "<s_cord-v2>"
        decoder_input_ids = processor.tokenizer(task_prompt, add_special_tokens=False, return_tensors="pt")["input_ids"]

        device = "cuda" if torch.cuda.is_available() else "cpu"
        model.to(device)

        outputs = model.generate(pixel_values.to(device),
                                 decoder_input_ids=decoder_input_ids.to(device),
                                 max_length=model.decoder.config.max_position_embeddings,
                                 early_stopping=True,
                                 pad_token_id=processor.tokenizer.pad_token_id,
                                 eos_token_id=processor.tokenizer.eos_token_id,
                                 use_cache=True,
                                 num_beams=1,
                                 bad_words_ids=[[processor.tokenizer.unk_token_id]],
                                 return_dict_in_generate=True,
                                 output_scores=True)

        # Decode output
        sequence = processor.batch_decode(outputs.sequences)[0]
        sequence = sequence.replace(processor.tokenizer.eos_token, "").replace(processor.tokenizer.pad_token, "")
        sequence = re.sub(r"<.*?>", "", sequence, count=1).strip()

        # Convert to JSON
        processor_json = processor.token2json(sequence)

        # Display the result
        st.subheader("Extracted Data")
        st.json(processor_json)

        # Save the result in the database (PostgreSQL expects JSON data to be a string)
        json_data_str = json.dumps(processor_json)  # Convert JSON object to string
        c.execute("INSERT INTO extracted_data (image_name, data) VALUES (%s, %s)", 
                  (uploaded_file.name, json_data_str))
        conn.commit()

        st.success("Data saved to database successfully!")

    except Exception as e:
        st.error(f"Error processing the image: {e}")

# Display data in table format
st.subheader("Stored Data in Database")
try:
    c.execute("SELECT * FROM extracted_data")
    rows = c.fetchall()

    # Define column headers
    column_headers = ["ID", "Image Name", "Data (JSON)"]

    # Convert the data into a pandas DataFrame for better display in Streamlit
    df = pd.DataFrame(rows, columns=column_headers)

    # Display the table using Streamlit
    st.dataframe(df)

except Exception as e:
    st.error(f"Error retrieving data from the database: {e}")

# Close the database connection when done
conn.close()
